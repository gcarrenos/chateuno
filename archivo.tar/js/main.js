
$( document ).ready(function() {

$(".DescargaId").click(function(){
        jQuery.ajax({
    url: "https://dev.biialab.org:1992/asokdsoal/getcedulas",
    type: "GET",
        })
        .done(function(data, textStatus, jqXHR) {
            console.log("HTTP Request Succeeded: " + jqXHR.status);
            alert("Descargando IDs ")
        })
        .fail(function(jqXHR, textStatus, errorThrown) {
            console.log("HTTP Request Failed");
        })
        .always(function() {
            /* ... */
        });
})
    
$(".DisparaPesOe").click(function(){
	jQuery.ajax({
    url: "https://dev.biialab.org:1992/asokdsoal/cleanchat",
    type: "POST",
	})
	.done(function(data, textStatus, jqXHR) {
	    console.log("HTTP Request Succeeded: " + jqXHR.status);
	    alert("Chat Borrado 📜 ")
	})
	.fail(function(jqXHR, textStatus, errorThrown) {
	    console.log("HTTP Request Failed");
	})
	.always(function() {
	    /* ... */
	});
})

});
